const express = require("express");
const Database = require("better-sqlite3");
const cors = require("cors");
const path = require("path");

// ── Config ──────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
const DB_PATH = process.env.DB_PATH || path.join(__dirname, "quiz_data.db");

// ── Database Setup ──────────────────────────────────────────────────────────
const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS submissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    verdict TEXT NOT NULL,
    explanation TEXT,
    submitted_at TEXT DEFAULT (datetime('now')),
    ip_address TEXT,
    user_agent TEXT
  );

  CREATE TABLE IF NOT EXISTS answers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    submission_id INTEGER NOT NULL,
    question_number INTEGER NOT NULL,
    question_text TEXT NOT NULL,
    answer_text TEXT NOT NULL,
    question_type TEXT NOT NULL DEFAULT 'multiple',
    FOREIGN KEY (submission_id) REFERENCES submissions(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_submissions_date ON submissions(submitted_at);
  CREATE INDEX IF NOT EXISTS idx_answers_submission ON answers(submission_id);
`);

// Prepared statements for performance
const insertSubmission = db.prepare(`
  INSERT INTO submissions (name, verdict, explanation, ip_address, user_agent)
  VALUES (@name, @verdict, @explanation, @ip_address, @user_agent)
`);

const insertAnswer = db.prepare(`
  INSERT INTO answers (submission_id, question_number, question_text, answer_text, question_type)
  VALUES (@submission_id, @question_number, @question_text, @answer_text, @question_type)
`);

const submitQuiz = db.transaction((data, meta) => {
  const result = insertSubmission.run({
    name: data.name,
    verdict: data.verdict,
    explanation: data.explanation || "",
    ip_address: meta.ip || "unknown",
    user_agent: meta.userAgent || "unknown",
  });

  const submissionId = result.lastInsertRowid;

  for (const answer of data.answers) {
    insertAnswer.run({
      submission_id: submissionId,
      question_number: answer.questionNumber,
      question_text: answer.questionText,
      answer_text: answer.answerText,
      question_type: answer.questionType || "multiple",
    });
  }

  return submissionId;
});

// ── Express App ─────────────────────────────────────────────────────────────
const app = express();
app.use(cors());
app.use(express.json());

// Trust proxy for real IPs behind reverse proxy
app.set("trust proxy", true);

// ── API Routes ──────────────────────────────────────────────────────────────

// POST /api/submit — Submit a quiz result
app.post("/api/submit", (req, res) => {
  try {
    const { name, verdict, explanation, answers } = req.body;

    if (!name || !verdict || !Array.isArray(answers) || answers.length === 0) {
      return res.status(400).json({
        error: "Missing required fields: name, verdict, answers[]",
      });
    }

    const submissionId = submitQuiz(
      { name, verdict, explanation, answers },
      {
        ip: req.ip,
        userAgent: req.get("User-Agent"),
      }
    );

    res.status(201).json({ success: true, id: submissionId });
  } catch (err) {
    console.error("Submit error:", err);
    res.status(500).json({ error: "Failed to save submission" });
  }
});

// GET /api/submissions — List all submissions (with pagination)
app.get("/api/submissions", (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 25));
    const offset = (page - 1) * limit;

    const total = db
      .prepare("SELECT COUNT(*) as count FROM submissions")
      .get().count;

    const submissions = db
      .prepare(
        `SELECT id, name, verdict, explanation, submitted_at, ip_address
         FROM submissions ORDER BY submitted_at DESC LIMIT ? OFFSET ?`
      )
      .all(limit, offset);

    res.json({
      data: submissions,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (err) {
    console.error("List error:", err);
    res.status(500).json({ error: "Failed to fetch submissions" });
  }
});

// GET /api/submissions/:id — Get a single submission with all answers
app.get("/api/submissions/:id", (req, res) => {
  try {
    const submission = db
      .prepare(
        `SELECT id, name, verdict, explanation, submitted_at, ip_address, user_agent
         FROM submissions WHERE id = ?`
      )
      .get(req.params.id);

    if (!submission) {
      return res.status(404).json({ error: "Submission not found" });
    }

    const answers = db
      .prepare(
        `SELECT question_number, question_text, answer_text, question_type
         FROM answers WHERE submission_id = ? ORDER BY question_number`
      )
      .all(submission.id);

    res.json({ ...submission, answers });
  } catch (err) {
    console.error("Fetch error:", err);
    res.status(500).json({ error: "Failed to fetch submission" });
  }
});

// DELETE /api/submissions/:id — Delete a submission
app.delete("/api/submissions/:id", (req, res) => {
  try {
    const result = db
      .prepare("DELETE FROM submissions WHERE id = ?")
      .run(req.params.id);

    if (result.changes === 0) {
      return res.status(404).json({ error: "Submission not found" });
    }

    res.json({ success: true, deleted: req.params.id });
  } catch (err) {
    console.error("Delete error:", err);
    res.status(500).json({ error: "Failed to delete submission" });
  }
});

// GET /api/stats — Aggregate stats
app.get("/api/stats", (req, res) => {
  try {
    const total = db
      .prepare("SELECT COUNT(*) as count FROM submissions")
      .get().count;

    const yesCount = db
      .prepare("SELECT COUNT(*) as count FROM submissions WHERE verdict = 'YES'")
      .get().count;

    const noCount = db
      .prepare("SELECT COUNT(*) as count FROM submissions WHERE verdict = 'NO'")
      .get().count;

    const recentSubmissions = db
      .prepare(
        `SELECT id, name, verdict, submitted_at
         FROM submissions ORDER BY submitted_at DESC LIMIT 10`
      )
      .all();

    // Most popular answers per question
    const popularAnswers = db
      .prepare(
        `SELECT question_number, question_text, answer_text, COUNT(*) as count
         FROM answers
         WHERE question_type = 'multiple'
         GROUP BY question_number, answer_text
         ORDER BY question_number, count DESC`
      )
      .all();

    // Group by question
    const byQuestion = {};
    for (const row of popularAnswers) {
      if (!byQuestion[row.question_number]) {
        byQuestion[row.question_number] = {
          question: row.question_text,
          answers: [],
        };
      }
      byQuestion[row.question_number].answers.push({
        answer: row.answer_text,
        count: row.count,
      });
    }

    res.json({
      total,
      yesCount,
      noCount,
      yesPercent: total > 0 ? Math.round((yesCount / total) * 100) : 0,
      recentSubmissions,
      answerBreakdown: byQuestion,
    });
  } catch (err) {
    console.error("Stats error:", err);
    res.status(500).json({ error: "Failed to fetch stats" });
  }
});

// GET /api/export — Export all data as JSON
app.get("/api/export", (req, res) => {
  try {
    const submissions = db
      .prepare(
        `SELECT id, name, verdict, explanation, submitted_at, ip_address
         FROM submissions ORDER BY submitted_at DESC`
      )
      .all();

    const answers = db
      .prepare(
        `SELECT submission_id, question_number, question_text, answer_text, question_type
         FROM answers ORDER BY submission_id, question_number`
      )
      .all();

    // Group answers by submission
    const answerMap = {};
    for (const a of answers) {
      if (!answerMap[a.submission_id]) answerMap[a.submission_id] = [];
      answerMap[a.submission_id].push(a);
    }

    const fullData = submissions.map((s) => ({
      ...s,
      answers: answerMap[s.id] || [],
    }));

    res.setHeader("Content-Disposition", "attachment; filename=bohemian_quiz_export.json");
    res.json(fullData);
  } catch (err) {
    console.error("Export error:", err);
    res.status(500).json({ error: "Failed to export data" });
  }
});

// ── Admin Dashboard (HTML) ──────────────────────────────────────────────────
app.get("/", (req, res) => {
  res.send(ADMIN_HTML);
});

const ADMIN_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bohemian Quiz — Admin Dashboard</title>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,900;1,400&family=Libre+Baskerville:ital@0;1&display=swap" rel="stylesheet">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Libre Baskerville', Georgia, serif;
      background: #F5EDE3;
      color: #3B2F2F;
      min-height: 100vh;
    }
    header {
      background: linear-gradient(135deg, #4A3728, #6B3A1B);
      color: #FFF8F0;
      padding: 28px 32px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 12px;
    }
    header h1 {
      font-family: 'Playfair Display', serif;
      font-size: 28px;
      font-weight: 900;
      font-style: italic;
    }
    header .actions { display: flex; gap: 10px; }
    header .actions a, header .actions button {
      padding: 10px 20px;
      border-radius: 24px;
      font-family: 'Playfair Display', serif;
      font-size: 14px;
      font-weight: 700;
      cursor: pointer;
      text-decoration: none;
      border: 2px solid #C49A6C;
      background: transparent;
      color: #C49A6C;
      transition: all 0.2s;
    }
    header .actions a:hover, header .actions button:hover {
      background: #C49A6C;
      color: #3B2F2F;
    }
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 16px;
      padding: 24px 32px;
    }
    .stat-card {
      background: #FFFCF7;
      border-radius: 14px;
      padding: 24px;
      text-align: center;
      box-shadow: 0 2px 12px rgba(80,50,20,0.06);
      border: 1px solid rgba(180,150,110,0.15);
    }
    .stat-card .number {
      font-family: 'Playfair Display', serif;
      font-size: 42px;
      font-weight: 900;
      color: #6B3A1B;
    }
    .stat-card .label {
      font-size: 13px;
      color: #8B7A6A;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-top: 4px;
    }
    .section { padding: 0 32px 32px; }
    .section h2 {
      font-family: 'Playfair Display', serif;
      font-size: 22px;
      font-style: italic;
      margin-bottom: 16px;
      color: #4A3728;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      background: #FFFCF7;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 2px 12px rgba(80,50,20,0.06);
    }
    th {
      background: rgba(139,90,43,0.08);
      text-align: left;
      padding: 14px 16px;
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: #6B4A2E;
      font-weight: 700;
    }
    td {
      padding: 14px 16px;
      border-top: 1px solid rgba(180,150,110,0.12);
      font-size: 14px;
    }
    tr:hover td { background: rgba(139,90,43,0.03); }
    .verdict-yes {
      color: #2D7A3A;
      font-weight: 700;
      background: rgba(45,122,58,0.08);
      padding: 4px 12px;
      border-radius: 20px;
      font-size: 12px;
    }
    .verdict-no {
      color: #8B4A4A;
      font-weight: 700;
      background: rgba(139,74,74,0.08);
      padding: 4px 12px;
      border-radius: 20px;
      font-size: 12px;
    }
    .btn-view, .btn-delete {
      padding: 6px 14px;
      border-radius: 16px;
      font-size: 12px;
      cursor: pointer;
      border: none;
      font-family: inherit;
      margin-right: 4px;
    }
    .btn-view { background: #8B5A2B; color: white; }
    .btn-delete { background: #C44; color: white; }
    .btn-view:hover { background: #6B3A1B; }
    .btn-delete:hover { background: #A33; }
    .pagination {
      display: flex;
      justify-content: center;
      gap: 8px;
      margin-top: 20px;
    }
    .pagination button {
      padding: 8px 18px;
      border: 1px solid #C4A882;
      background: #FFFCF7;
      border-radius: 20px;
      cursor: pointer;
      font-family: inherit;
      font-size: 13px;
    }
    .pagination button:disabled { opacity: 0.4; cursor: default; }
    .pagination button:not(:disabled):hover { background: #8B5A2B; color: white; border-color: #8B5A2B; }
    .modal-overlay {
      position: fixed; inset: 0;
      background: rgba(0,0,0,0.5);
      display: flex; align-items: center; justify-content: center;
      z-index: 999;
    }
    .modal {
      background: #FFFCF7;
      border-radius: 16px;
      padding: 32px;
      max-width: 640px;
      width: 90%;
      max-height: 80vh;
      overflow-y: auto;
      box-shadow: 0 20px 60px rgba(0,0,0,0.2);
    }
    .modal h3 {
      font-family: 'Playfair Display', serif;
      font-size: 24px;
      margin-bottom: 8px;
    }
    .modal .close-btn {
      float: right;
      background: none;
      border: none;
      font-size: 24px;
      cursor: pointer;
      color: #8B7A6A;
    }
    .answer-item {
      padding: 12px 0;
      border-bottom: 1px solid rgba(180,150,110,0.15);
    }
    .answer-item .q {
      font-size: 13px;
      color: #8B7A6A;
      font-style: italic;
      margin-bottom: 4px;
    }
    .answer-item .a { font-size: 15px; color: #3B2F2F; }
    .empty { text-align: center; padding: 40px; color: #8B7A6A; font-style: italic; }
  </style>
</head>
<body>
  <header>
    <h1>&#127803; Bohemian Quiz Admin</h1>
    <div class="actions">
      <a href="/api/export" download>Export JSON</a>
      <button onclick="loadData()">Refresh</button>
    </div>
  </header>

  <div class="stats-grid" id="stats"></div>

  <div class="section">
    <h2>All Submissions</h2>
    <div id="table-container"></div>
    <div class="pagination" id="pagination"></div>
  </div>

  <div id="modal-root"></div>

  <script>
    let currentPage = 1;
    const LIMIT = 25;

    async function loadData() {
      await loadStats();
      await loadSubmissions(currentPage);
    }

    async function loadStats() {
      try {
        const res = await fetch('/api/stats');
        const data = await res.json();
        document.getElementById('stats').innerHTML = \`
          <div class="stat-card">
            <div class="number">\${data.total}</div>
            <div class="label">Total Responses</div>
          </div>
          <div class="stat-card">
            <div class="number" style="color:#2D7A3A">\${data.yesCount}</div>
            <div class="label">Bohemians</div>
          </div>
          <div class="stat-card">
            <div class="number" style="color:#8B4A4A">\${data.noCount}</div>
            <div class="label">Not Bohemian</div>
          </div>
          <div class="stat-card">
            <div class="number">\${data.yesPercent}%</div>
            <div class="label">Bohemian Rate</div>
          </div>
        \`;
      } catch (e) { console.error('Stats error', e); }
    }

    async function loadSubmissions(page) {
      try {
        const res = await fetch(\`/api/submissions?page=\${page}&limit=\${LIMIT}\`);
        const { data, pagination } = await res.json();
        currentPage = pagination.page;

        if (data.length === 0) {
          document.getElementById('table-container').innerHTML =
            '<div class="empty">No submissions yet. Share the quiz and watch responses roll in!</div>';
          document.getElementById('pagination').innerHTML = '';
          return;
        }

        let html = '<table><thead><tr>';
        html += '<th>ID</th><th>Name</th><th>Verdict</th><th>Date</th><th>Actions</th>';
        html += '</tr></thead><tbody>';

        for (const s of data) {
          const date = new Date(s.submitted_at + 'Z').toLocaleString();
          const vc = s.verdict === 'YES' ? 'verdict-yes' : 'verdict-no';
          html += \`<tr>
            <td>#\${s.id}</td>
            <td><strong>\${esc(s.name)}</strong></td>
            <td><span class="\${vc}">\${s.verdict}</span></td>
            <td>\${date}</td>
            <td>
              <button class="btn-view" onclick="viewSubmission(\${s.id})">View</button>
              <button class="btn-delete" onclick="deleteSubmission(\${s.id})">Delete</button>
            </td>
          </tr>\`;
        }
        html += '</tbody></table>';
        document.getElementById('table-container').innerHTML = html;

        // Pagination
        let pag = '';
        pag += \`<button \${page <= 1 ? 'disabled' : ''} onclick="loadSubmissions(\${page - 1})">&larr; Prev</button>\`;
        pag += \`<button disabled>Page \${page} of \${pagination.totalPages}</button>\`;
        pag += \`<button \${page >= pagination.totalPages ? 'disabled' : ''} onclick="loadSubmissions(\${page + 1})">Next &rarr;</button>\`;
        document.getElementById('pagination').innerHTML = pag;
      } catch (e) { console.error('Load error', e); }
    }

    async function viewSubmission(id) {
      try {
        const res = await fetch('/api/submissions/' + id);
        const data = await res.json();

        const vc = data.verdict === 'YES' ? 'verdict-yes' : 'verdict-no';
        let html = \`<div class="modal-overlay" onclick="closeModal(event)">
          <div class="modal" onclick="event.stopPropagation()">
            <button class="close-btn" onclick="closeModal()">&times;</button>
            <h3>\${esc(data.name)}</h3>
            <p><span class="\${vc}">\${data.verdict}</span> &mdash; \${new Date(data.submitted_at + 'Z').toLocaleString()}</p>
            <p style="margin:12px 0;font-style:italic;color:#6B4A2E;">\${esc(data.explanation)}</p>
            <hr style="border:none;border-top:1px solid rgba(180,150,110,0.2);margin:16px 0;">
            <h4 style="font-size:14px;text-transform:uppercase;letter-spacing:1px;color:#8B7A6A;margin-bottom:8px;">Answers</h4>
        \`;

        for (const a of data.answers) {
          html += \`<div class="answer-item">
            <div class="q">Q\${a.question_number}: \${esc(a.question_text)}</div>
            <div class="a">\${esc(a.answer_text)}</div>
          </div>\`;
        }

        html += '</div></div>';
        document.getElementById('modal-root').innerHTML = html;
      } catch (e) { console.error('View error', e); }
    }

    function closeModal(e) {
      if (!e || e.target.classList.contains('modal-overlay') || e.target.classList.contains('close-btn')) {
        document.getElementById('modal-root').innerHTML = '';
      }
    }

    async function deleteSubmission(id) {
      if (!confirm('Delete submission #' + id + '? This cannot be undone.')) return;
      try {
        await fetch('/api/submissions/' + id, { method: 'DELETE' });
        loadData();
      } catch (e) { console.error('Delete error', e); }
    }

    function esc(str) {
      const d = document.createElement('div');
      d.textContent = str || '';
      return d.innerHTML;
    }

    loadData();
  </script>
</body>
</html>`;

// ── Start Server ────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════════════╗
║  🌻 Bohemian Quiz Backend running on port ${PORT}        ║
╠══════════════════════════════════════════════════════╣
║                                                      ║
║  Admin Dashboard:  http://localhost:${PORT}              ║
║                                                      ║
║  API Endpoints:                                      ║
║  POST   /api/submit          Submit quiz results     ║
║  GET    /api/submissions     List all (paginated)    ║
║  GET    /api/submissions/:id View single submission  ║
║  DELETE /api/submissions/:id Delete a submission     ║
║  GET    /api/stats           Aggregate statistics    ║
║  GET    /api/export          Export all data (JSON)  ║
║                                                      ║
╚══════════════════════════════════════════════════════╝
  `);
});

module.exports = app;
