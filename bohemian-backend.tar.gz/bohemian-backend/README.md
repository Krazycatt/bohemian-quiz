# 🌻 Bohemian Quiz — Backend

A Node.js/Express backend with SQLite to collect and manage all quiz submissions from the "Are You Bohemian?" personality quiz.

## Quick Start

```bash
# Install dependencies
npm install

# Start the server
npm start
```

The server runs on **http://localhost:3000** by default.

## What You Get

### Admin Dashboard
Visit **http://localhost:3000** in your browser to see:
- Live stats (total responses, bohemian %, yes/no counts)
- Searchable table of all submissions
- Click **View** on any row to see full answers
- **Delete** individual submissions
- **Export JSON** button to download all data

### API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/submit` | Submit a quiz result |
| `GET` | `/api/submissions` | List all submissions (paginated) |
| `GET` | `/api/submissions/:id` | View single submission + answers |
| `DELETE` | `/api/submissions/:id` | Delete a submission |
| `GET` | `/api/stats` | Aggregate statistics |
| `GET` | `/api/export` | Export all data as JSON |

### Pagination
```
GET /api/submissions?page=1&limit=25
```

## Data Storage

All data is stored in `quiz_data.db` (SQLite) in the project root. The database is created automatically on first run.

**Two tables:**
- `submissions` — name, verdict, explanation, timestamp, IP, user agent
- `answers` — each individual question/answer linked to a submission

## Connecting the Quiz Frontend

In the quiz React component, set the `API_URL` constant at the top:

```js
const API_URL = "http://localhost:3000";
```

The quiz will POST results automatically after Claude judges them. If the backend is down, the quiz still works — it just won't save.

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `3000` | Server port |
| `DB_PATH` | `./quiz_data.db` | SQLite database file path |

## Example: Submit via cURL

```bash
curl -X POST http://localhost:3000/api/submit \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Luna",
    "verdict": "YES",
    "explanation": "A true free spirit!",
    "answers": [
      {
        "questionNumber": 1,
        "questionText": "Your ideal Friday night looks like…",
        "answerText": "An underground poetry slam or live jazz in a dimly lit bar",
        "questionType": "multiple"
      }
    ]
  }'
```
